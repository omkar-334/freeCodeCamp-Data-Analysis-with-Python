from __future__ import annotations

from poetry.core.constraints.version import VersionRange


__all__ = ["VersionRange"]
