from __future__ import annotations

from poetry.core.constraints.version import constraint_regions


__all__ = ["constraint_regions"]
