from __future__ import annotations

from poetry.core.constraints.version import VersionRangeConstraint


__all__ = ["VersionRangeConstraint"]
